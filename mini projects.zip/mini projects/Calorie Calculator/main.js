
// Calories/day = 10 × weight in kg + 6.25 × height in cm − 5 × age in years + 5


let cbtn = document.getElementById("calculate_cal")

cbtn.onclick = () =>{

    let inputs = document.getElementsByClassName("cal_inputs")

    let height = inputs[0].value

    let weight = inputs[1].value

    let age = inputs [2].value

    
    console.log(`entred height is ${height}, weight is ${weight} , age is ${age}`)
           

    // let body_type;

    // if(bmi < 18){
    //     body_type = "your are underweight"
    // }else if(bmi > 18 && bmi < 24){
    //     body_type = "your are normal weight"
    // }else{
    //     body_type = "your are overweight"
    // }


    // document.getElementById("your_bmi").innerHTML = `Your BMI Score is ${bmi} & ${body_type}`

}

